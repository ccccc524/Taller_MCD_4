#######################################################################################
#######################################################################################
################      CLASE 11                     ####################################
################  MCD Carlos Castro Correa        #####################################
#######################################################################################
#######################################################################################

#Contenido: Undersampling / Oversampling y deplyment Shiny

#Paquetes
library(readr)
library(tidyverse)
library(leaflet)
library(leaflet.extras)
library(rpart) 
library(rpart.plot) 
library(readxl)
library(xgboost) 
library(tidymodels) 
library(cluster) 
library(caret)





#######################################################################################
#######################################################################################
################ Tableros Shiny individuales      #####################################
#######################################################################################
#######################################################################################




#######################################################################################
#######################################################################################
################     Deployment Shiny              ####################################
#######################################################################################
#######################################################################################

library(rsconnect)

setwd("~/Desktop/Carlos/cursos/ITAM/Taller_MCD_agosto2026/Clase11")

#Importante: el .R se debe llamar app.R (yo renombré el quinto archivo de Shiny)...


# Se corre una sola vez: pega aquí tu token y secret de shinyapps.io
rsconnect::setAccountInfo(name='carloshasel', 
                          token='XXXX', 
                          secret='XXXX')

deployApp(
  appDir  = "tablero_flota",
  appName = "tablero_flota",
  account = "carloshasel"
)











#######################################################################################
######## Unbalanced            ########################################################
#######################################################################################

#Semilla
set.seed(1035)

#Leemos los datos
setwd("~/Desktop/Carlos/cursos/ITAM/Taller_MCD_agosto2026/Clase11")
unbalanced <- read_excel("unbalanced.xlsx")

#Observamos los datos
View(unbalanced)

#Cambiamos a factor
unbalanced$in_sf <- as.factor(unbalanced$in_sf)


#¿Cuántos registros tiene por cada categoría NY - SFO nuestra base unbalanced?
unbalanced$in_sf %>% table()

(unbalanced$in_sf %>% table()) / nrow(unbalanced)


#¿Cuál es el efecto de este desequilibrio en las predicciones?
#¿Tendrán la misma eficiencia para ambas clases?...

#Utilizamos un algoritmo de ML para probar...

#Columna auxiliar
unbalanced$ID <- 1:nrow(unbalanced)
#Estoy creando este ID para identificar los registros que utilizo como entrenamiento y prueba...

View(unbalanced) #Solo agregue un índice...

#Separamos el conjunto original en entrenamiento y prueba - considerando que no tengo que evitar filtraciones...
ent <- sample_frac(tbl = unbalanced,size = 0.8) #entrenamiento
pru <- unbalanced %>% filter(!ID %in% ent$ID) #prueba

#Reviso tamaños:
dim(ent)
dim(pru)

#¿Crees que el desbalance se herede a los conjuntos de entrenamiento y prueba?
ent$in_sf %>% table()
(ent$in_sf %>% table()) / nrow(ent)

pru$in_sf %>% table()
(pru$in_sf %>% table()) / nrow(pru)

#El de la base original era:
unbalanced$in_sf %>% table()
(unbalanced$in_sf %>% table()) / nrow(unbalanced)

#El desbalance se hereda porque.... la muestra fue aleatoria...

#Quitamos ID
ent <- ent %>% select(-ID)
pru <- pru %>% select(-ID)


#En conclusión: 
# 1.Tenemos mucho menos información de los deptos de NY... de los de SFO tenemos más
# 2.¿Qué podría suceder en las predicciones? ¿Qué resultados esperarías?...

#Veamos a continuación con un modelo de ML...

#Arbol de decisión y error de prueba...
#Modelo ML con datos de entrenamiento

#Corremos un árbol de decisión
tree_ent <- rpart(in_sf ~ ., data = ent) #Recuerda que ent, es el conjunto de entranmiento del conjunto desbalanceado...

#Predecimos en el conjunto de prueba (observa que newdata es pru, no ent... es decir, datos que no ha visto...)
pru$pred <- predict(object = tree_ent,newdata = pru,type = "class")

#Matriz de confusion prueba
conf_pru <- confusionMatrix(data=pru$pred, reference = pru$in_sf)

conf_pru$table #Observa que el accuracy no es "tan malo"... pero...

conf_pru

#De los registros que son de SFO, ¿cuántos son etiquetas correctamente?
24 / 26  

#De los registros que son de NY, ¿cuántos son etiquetas correctamente?
3 / 9

#La diferencia en predicciones correctas para cada clase es ABISMAL...
#y gran parte de debe al desequilibrio de clases...

#Incluso, el conjunto de prueba también esta desequilibrado:
pru$in_sf %>% table()

#¿Cómo podemos compensar este efecto? ¿Hay alguna posibilidad?...

#...
#Por cierto, recuerda que las métricas anteriores se llaman Especifidad y Sensibilidad y nos 
#las entrega el comando confusionMatrix()

conf_pru$byClass

# Sensibilidad
conf_pru$byClass[1]
# Especifidad
conf_pru$byClass[2]




















#######################################################################################
######## Undersampling            #####################################################
#######################################################################################

#Utilizamos los mismos conjuntos de entrenamiento y prueba del ejemplo unbalanced

#Datos de entrenamiento
dim(ent) #140 registros

#Clases
ent$in_sf %>% table()

# 0   1 
# 31 109 

#Separo el conjunto de entrenamiento por clase:

#Observaciones por clase
ent_sfo <- filter(ent,in_sf == 1) #109 registros SF
dim(ent_sfo)

ent_ny <- filter(ent,in_sf == 0) #31 registros NY
dim(ent_ny)

#Tengo que hacer un nuevo conjunto de entrenamiento con 62 registros (31 SF y 31 NY)

#Con los 109 datos de SF0, hacemos clustering con 31 grupos...
model_31=kmeans(ent_sfo,31)

model_31

#En este caso, el withinss y el número de miembros por grupo no nos importan tanto...
#¿por qué?...

#Centroides
model_31$centers %>% View()
#Este es mi "nuevo conjunto" SFO


######Rediseño del conjunto de entrenamiento - 62 registros en total
ent_bis <- rbind(model_31$centers,ent_ny) #Pegamos los nuevos centroides (Nuevo datos de SF)
#y los datos de NY (el que tenía menos registros)

dim(ent_bis) #manipulado pero completamente balanceado
ent_bis$in_sf %>% table()

#Dimensiones
dim(ent) #original y desbalanceado
ent$in_sf %>% table()

#¿Cómo funcionan ahora nuestras predicciones?...

#####Modelo ML con datos undersampling (ent_bis) y 
#lo probamos con el conjunto de prueba original (pru)...

#########Diseñamos un nuevo árbol con los datos ent_bis
tree_ent_bis <- rpart(in_sf ~ ., data = ent_bis) #ent_bis ya está "eauilibrado"

#Predecimos en el conjunto de prueba original (eso no lo hemos manipulado)
pru$pred_bis <- predict(object = tree_ent_bis,newdata = pru,type = "class")

#Matriz de confusion prueba con ent_bis (con undersamplig)
conf_pru_bis <- confusionMatrix(data=pru$pred_bis, reference = pru$in_sf)

conf_pru_bis$table

#Matriz de confunsión original (sin datos undersampling...)
conf_pru$table

#¿Puedes notar la diferencia en la clase NY?...

#Sensibilidad
conf_pru$byClass[1] #Muy pocos registros de NY con los datos originales y desequilibrados...
conf_pru_bis$byClass[1] #El algoritmo predijo correctamente todos los registros de NY, con datos manipulados...

#Aclaración: Es un caso extremo con gran desempeño (no siempre es así...)


#¿Pero qué sucede con la clase SFO?...

#Especificidad
conf_pru$byClass[2]
conf_pru_bis$byClass[2] #Se redujo al manipular los datos, ¿por qué ocurre?
#Recuerda que pasamos de tener 109 registros a tener solo 31... con centroides de clústeres


#Entonces ¿qué podemos hacer?...

#1.Mezclar modelos
#2. Entrenar muchos algoritmos y medir
#3. Probar, probar y escoger la mejor opción 
#4. Modelos ensamble https://www.ibm.com/think/topics/ensemble-learning
#5. Programar de forma eficiente en memoria y aprovechar Docker y cómputo en la nube...
#https://www.docker.com/

#Mil opciones, ajustes y técnicas que nos podrían llevar todo un curso completo...o Maestría...










#######################################################################################
# Veamos el resto de los modelos de undersampling:

#Undersampling con reemplazo
#Observaciones por clase
ent_sfo <- filter(ent,in_sf == 1) #109 registros
dim(ent_sfo)

ent_ny <- filter(ent,in_sf == 0) #31 registros
dim(ent_ny)


#Con reemplazo
ent_sfo_bis <- sample_n(ent_sfo,size = 31) #Dame 31 registros de forma aleatoria, 
#cada registro puede ser seleccionado más de una vez...

######Rediseño del conjunto de entrenamiento
ent_bis <- rbind(ent_sfo_bis,ent_ny)

#Revisamos el nuevo tamaño:
dim(ent_bis) #(31 +31)


#########Diseñamos un nuevo árbol con los datos ent_bis
tree_ent_bis <- rpart(in_sf ~ ., data = ent_bis)

#Predecimos en el conjunto de prueba
pru$pred_bis <- predict(object = tree_ent_bis,newdata = pru,type = "class")

#Matriz de confusion prueba con ent_bis (con undersamplig)
conf_pru_bis_reemplazo <- confusionMatrix(data=pru$pred_bis, reference = pru$in_sf)
conf_pru_bis_reemplazo$table


#Resumen

#Normal (datos desequilibrados...)
conf_pru$table
#Undersampling con clustering
conf_pru_bis$table
#Undersampling sin reemplazo
conf_pru_bis_reemplazo$table

#Metricas resumen
mat <- data.frame(modelos = c("normal","under_clustering","under_sin"),
                  accuracy = c(conf_pru$overall[1], conf_pru_bis$overall[1],
                               conf_pru_bis_reemplazo$overall[1]))

#Observamos resultados accuracy por cada tipo de remuestreo:
mat

#¿Por qué es más bajo con clustering?... menos datos totales por undersampling...
#¿Pasa lo mismo con sensibilidad y especificidad?...



















