#######################################################################################
#######################################################################################
################      CLASE 11                     ####################################
################   MCD Carlos Castro Correa        ####################################
################       Shiny 1                     ####################################
#######################################################################################
#######################################################################################

#EJEMPLO 1 (BASICO): Grafica de barras con un filtro
#Que aprenderemos:
  #1. La estructura minima de una app Shiny: ui + server + shinyApp
  #2. Un input (selectInput) que cambia lo que se grafica
  #3. renderPlot / plotOutput

#Paquetes
library(shiny)
library(tidyverse)


#######################################################################################
#Base de datos inventada (en la vida real aqui leerias tu csv con read_csv)
set.seed(123)   #para que a todos nos salgan los mismos números

base <- expand_grid(
  region   = c("Norte", "Centro", "Sur"),
  producto = c("Gas LP", "Diesel", "Gasolina", "Lubricantes")
) %>%
  mutate(ventas_mdp = round(runif(n(), min = 5, max = 60), 1))   #ventas en millones de pesos

#Vemos la base (corre esto en consola para ver como luce)
#head(base)


#######################################################################################
#UI (lo que ve el usuario)
ui <- fluidPage(

  titlePanel("Ventas por producto"),

  sidebarLayout(

    #Panel izquierdo: aqui van los controles
    sidebarPanel(
      selectInput(
        inputId  = "region",            #este id es el que usamos en el server como input$region
        label    = "Selecciona una region",
        choices  = unique(base$region),
        selected = "Norte"
      )
    ),

    #Panel derecho: aqui van los resultados
    mainPanel(
      plotOutput("grafica_barras")      #el id debe coincidir con output$grafica_barras
    )
  )
)


#######################################################################################
#SERVER (la logica: aqui se hacen los calculos y las graficas)
server <- function(input, output, session) {

  output$grafica_barras <- renderPlot({

    #Filtramos la base con lo que eligio el usuario
    datos <- base %>%
      filter(region == input$region)

    #Grafica de barras
    ggplot(datos, aes(x = reorder(producto, -ventas_mdp), y = ventas_mdp)) +
      geom_col(fill = "#B91C1C") +
      geom_text(aes(label = ventas_mdp), vjust = -0.5) +   #etiqueta encima de cada barra
      labs(
        title = paste("Ventas en la region", input$region),
        x = NULL,
        y = "Millones de pesos"
      ) +
      theme_minimal(base_size = 14)
  })
}


#######################################################################################
#Lanzar la app
shinyApp(ui, server)
