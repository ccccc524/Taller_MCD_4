#######################################################################################
#######################################################################################
################      CLASE 11                     ####################################
################   MCD Carlos Castro Correa        ####################################
################       Shiny 2                     ####################################
#######################################################################################
#######################################################################################


#EJEMPLO 2 (BASICO-INTERMEDIO): Serie de tiempo con varios filtros
#Que aprenderemos:
  #1. Varios inputs al mismo tiempo (fechas, checkboxes, slider)
  #2. reactive(): calcular los datos filtrados UNA vez y usarlos en varios lugares
  #3. Una grafica de lineas con media movil

#Paquetes
library(shiny)
library(tidyverse)
library(lubridate)
library(scales)


#######################################################################################
#Base de datos inventada: litros vendidos al dia por sucursal durante 2025
set.seed(2025)

fechas <- seq(ymd("2025-01-01"), ymd("2025-12-31"), by = "day")

base <- expand_grid(
  fecha    = fechas,
  sucursal = c("Toluca", "Naucalpan", "Pachuca", "Cuernavaca")
) %>%
  mutate(
    #tendencia + estacionalidad (mas ventas en invierno) + ruido aleatorio
    litros = 8000 +
      2000 * cos(2 * pi * (yday(fecha) - 15) / 365) +
      as.numeric(factor(sucursal)) * 600 +
      rnorm(n(), mean = 0, sd = 700),
    litros = round(pmax(litros, 0))
  )

#Vemos la base
#head(base)

#######################################################################################
#UI
ui <- fluidPage(

  titlePanel("Litros vendidos por sucursal"),

  sidebarLayout(
    sidebarPanel(
      dateRangeInput(
        "fechas", "Periodo",
        start = ymd("2025-01-01"), end = ymd("2025-12-31"),
        min   = min(base$fecha),   max = max(base$fecha),
        language = "es"
      ),
      checkboxGroupInput(
        "sucursales", "Sucursales",
        choices  = unique(base$sucursal),
        selected = unique(base$sucursal)       #empiezan todas palomeadas
      ),
      sliderInput(
        "ventana", "Media movil (dias)",
        min = 1, max = 30, value = 7, step = 1
      )
    ),
    mainPanel(
      plotOutput("grafica_lineas", height = "450px"),
      textOutput("resumen")
    )
  )
)


#######################################################################################
#SERVER
server <- function(input, output, session) {

  #reactive: se recalcula solo cuando cambia algun input que usa adentro
  datos <- reactive({

    #req() frena el calculo si el usuario desmarco todas las sucursales (evita errores feos)
    req(input$sucursales)

    base %>%
      filter(
        fecha >= input$fechas[1], fecha <= input$fechas[2],
        sucursal %in% input$sucursales
      ) %>%
      group_by(sucursal) %>%
      arrange(fecha, .by_group = TRUE) %>%
      #media movil: promedio de los ultimos "ventana" dias
      mutate(media_movil = as.numeric(stats::filter(litros, rep(1 / input$ventana, input$ventana), sides = 1))) %>%
      ungroup()
  })

  output$grafica_lineas <- renderPlot({
    ggplot(datos(), aes(x = fecha, y = media_movil, color = sucursal)) +
      geom_line(linewidth = 1, na.rm = TRUE) +
      scale_y_continuous(labels = comma) +
      labs(
        title = paste("Media movil de", input$ventana, "dias"),
        x = NULL, y = "Litros por dia", color = "Sucursal"
      ) +
      theme_minimal(base_size = 14) +
      theme(legend.position = "bottom")
  })

  #Un texto que reutiliza los mismos datos filtrados
  output$resumen <- renderText({
    total <- sum(datos()$litros)
    paste("Total de litros en el periodo seleccionado:", comma(total))
  })
}


#######################################################################################
shinyApp(ui, server)
