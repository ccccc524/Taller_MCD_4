#######################################################################################
#######################################################################################
################      CLASE 11                     ####################################
################   MCD Carlos Castro Correa        ####################################
################       Shiny 3                     ####################################
#######################################################################################
#######################################################################################


#EJEMPLO 3 (INTERMEDIO): Grafica interactiva (plotly) conectada a una tabla (DT)
#Que aprenderemos:
  #1. Graficas interactivas: tooltips, zoom y seleccion con plotly
  #2. Tablas con buscador y orden con DT
  #3. Una caja seleccionada en la grafica filtra la tabla (comunicacion entre outputs)

#Paquetes
library(shiny)
library(tidyverse)
library(plotly)
library(DT)


#######################################################################################
#Base de datos inventada: 120 clientes con su consumo y margen
set.seed(42)

base <- tibble(
  cliente   = paste("Cliente", sprintf("%03d", 1:120)),
  segmento  = sample(c("Industrial", "Comercial", "Domestico"), 120, replace = TRUE, prob = c(0.2, 0.3, 0.5)),
  consumo_l = round(rlnorm(120, meanlog = 7, sdlog = 0.8)),            #litros al mes
  margen    = round(rnorm(120, mean = 12, sd = 4) + runif(120, 0, 3), 1)  #margen en %
) %>%
  mutate(
    #los industriales consumen mas
    consumo_l = if_else(segmento == "Industrial", consumo_l * 3, consumo_l),
    id = row_number()     #un id para poder identificar los puntos seleccionados
  )

#Vemos la base
#head(base)


#######################################################################################
#UI
ui <- fluidPage(

  titlePanel("Clientes: consumo vs margen"),

  fluidRow(
    column(3,
      selectInput("segmento", "Segmento",
                  choices = c("Todos", unique(base$segmento)), selected = "Todos"),
      sliderInput("margen_min", "Margen minimo (%)",
                  min = 0, max = 25, value = 0, step = 1),
      helpText("Tip: con la herramienta de caja (arriba de la grafica) selecciona puntos y mira la tabla.")
    ),
    column(9,
      plotlyOutput("dispersion", height = "420px")
    )
  ),

  hr(),
  h4("Detalle de clientes"),
  DTOutput("tabla")
)


#######################################################################################
#SERVER
server <- function(input, output, session) {

  #Datos filtrados por los controles
  datos <- reactive({
    d <- base %>% filter(margen >= input$margen_min)
    if (input$segmento != "Todos") d <- d %>% filter(segmento == input$segmento)
    d
  })

  output$dispersion <- renderPlotly({
    plot_ly(
      data = datos(),
      x = ~consumo_l, y = ~margen,
      color = ~segmento, colors = c("#B91C1C", "#1D4ED8", "#059669"),
      type = "scatter", mode = "markers",
      customdata = ~id,                                  #lo que recuperamos al seleccionar
      text = ~paste0(cliente, "<br>Consumo: ", format(consumo_l, big.mark = ","), " L<br>Margen: ", margen, "%"),
      hoverinfo = "text",
      source = "disp"                                    #nombre para identificar esta grafica
    ) %>%
      layout(
        xaxis = list(title = "Consumo mensual (litros)", type = "log"),
        yaxis = list(title = "Margen (%)"),
        dragmode = "select"                              #arrancar con la herramienta de seleccion
      ) %>%
      event_register("plotly_selected")
  })

  output$tabla <- renderDT({

    #Que puntos selecciono el usuario en la grafica (NULL si no ha seleccionado nada)
    sel <- event_data("plotly_selected", source = "disp")

    d <- datos()
    if (!is.null(sel) && nrow(sel) > 0) d <- d %>% filter(id %in% sel$customdata)

    d %>%
      select(Cliente = cliente, Segmento = segmento, `Consumo (L)` = consumo_l, `Margen (%)` = margen) %>%
      datatable(rownames = FALSE, options = list(pageLength = 8, language = list(search = "Buscar:")))
  })
}


#######################################################################################
shinyApp(ui, server)
