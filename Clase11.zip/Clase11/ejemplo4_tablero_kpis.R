#######################################################################################
#######################################################################################
################      CLASE 11                     ####################################
################   MCD Carlos Castro Correa        ####################################
################       Shiny 4                     ####################################
#######################################################################################
#######################################################################################


#EJEMPLO 4 (INTERMEDIO-AVANZADO): Tablero con KPIs, pestanas y varias graficas
#Que aprenderemos:
  #1. Layout moderno con bslib (page_navbar, cards, value_box)
  #2. KPIs que se actualizan con los filtros
  #3. Pestanas: cada una con su propia grafica/tabla
  #4. Una funcion auxiliar para no repetir codigo

#Paquetes
library(shiny)
library(bslib)
library(tidyverse)
library(lubridate)
library(scales)
library(DT)


#######################################################################################
#Base de datos inventada: ventas de un distribuidor (2 anios, 3 zonas, 4 productos)
set.seed(7)

base <- expand_grid(
  mes      = seq(ymd("2024-01-01"), ymd("2025-12-01"), by = "month"),
  zona     = c("Metropolitana", "Bajio", "Sureste"),
  producto = c("Gas LP", "Diesel", "Gasolina", "Lubricantes")
) %>%
  mutate(
    ventas = round(runif(n(), 8, 20) * (1 + 0.02 * as.numeric(factor(mes)) / 3) *
                     (1 + 0.15 * (as.numeric(factor(zona)) == 1)), 2),   #millones de pesos
    costo  = round(ventas * runif(n(), 0.70, 0.85), 2)
  ) %>%
  mutate(utilidad = ventas - costo)

#Veamos base
#head(base)


#######################################################################################
#Funciones auxiliares (las ponemos arriba para usarlas en el server)

#Formato de millones: 1234.5 -> "$1,234.5 M"
fmt_mdp <- function(x) paste0("$", comma(x, accuracy = 0.1), " M")


#######################################################################################
#UI
ui <- page_navbar(
  title = "Tablero comercial",
  theme = bs_theme(version = 5, primary = "#B91C1C"),

  #Barra lateral que aplica a todas las pestanas
  sidebar = sidebar(
    selectInput("anio", "Anio", choices = c(2025, 2024), selected = 2025),
    checkboxGroupInput("zonas", "Zonas",
                       choices = unique(base$zona), selected = unique(base$zona)),
    checkboxGroupInput("productos", "Productos",
                       choices = unique(base$producto), selected = unique(base$producto))
  ),

  #Pestana 1: resumen
  nav_panel("Resumen",
    layout_columns(
      fill = FALSE,    #para que los KPIs no se estiren a todo lo alto
      value_box("Ventas", textOutput("kpi_ventas"), theme = "primary"),
      value_box("Utilidad", textOutput("kpi_utilidad"), theme = "success"),
      value_box("Margen", textOutput("kpi_margen"), theme = "secondary")
    ),
    layout_columns(
      col_widths = c(8, 4),
      card(card_header("Ventas por mes"), plotOutput("g_mensual")),
      card(card_header("Ventas por producto"), plotOutput("g_producto"))
    )
  ),

  #Pestana 2: detalle por zona
  nav_panel("Por zona",
    card(card_header("Utilidad por zona y producto"), plotOutput("g_zona", height = "420px"))
  ),

  #Pestana 3: datos
  nav_panel("Datos",
    card(DTOutput("tabla"))
  )
)


#######################################################################################
#SERVER
server <- function(input, output, session) {

  #Datos filtrados (se usan en TODAS las pestanas)
  datos <- reactive({
    req(input$zonas, input$productos)
    base %>%
      filter(year(mes) == input$anio, zona %in% input$zonas, producto %in% input$productos)
  })

  #KPIs
  output$kpi_ventas   <- renderText(fmt_mdp(sum(datos()$ventas)))
  output$kpi_utilidad <- renderText(fmt_mdp(sum(datos()$utilidad)))
  output$kpi_margen   <- renderText(percent(sum(datos()$utilidad) / sum(datos()$ventas), accuracy = 0.1))

  #Graficas
  output$g_mensual <- renderPlot({
    datos() %>%
      group_by(mes) %>% summarise(ventas = sum(ventas)) %>%
      ggplot(aes(mes, ventas)) +
      geom_area(fill = "#FCA5A5", alpha = 0.6) +
      geom_line(color = "#B91C1C", linewidth = 1.1) +
      scale_x_date(date_labels = "%b") +
      labs(x = NULL, y = "Millones de pesos") +
      theme_minimal(base_size = 13)
  })

  output$g_producto <- renderPlot({
    datos() %>%
      group_by(producto) %>% summarise(ventas = sum(ventas)) %>%
      ggplot(aes(reorder(producto, ventas), ventas)) +
      geom_col(fill = "#B91C1C") +
      coord_flip() +
      labs(x = NULL, y = "Millones de pesos") +
      theme_minimal(base_size = 13)
  })

  output$g_zona <- renderPlot({
    datos() %>%
      group_by(zona, producto) %>% summarise(utilidad = sum(utilidad), .groups = "drop") %>%
      ggplot(aes(zona, utilidad, fill = producto)) +
      geom_col(position = "dodge") +
      scale_fill_brewer(palette = "Reds") +
      labs(x = NULL, y = "Utilidad (millones de pesos)", fill = "Producto") +
      theme_minimal(base_size = 13)
  })

  output$tabla <- renderDT({
    datos() %>%
      mutate(mes = format(mes, "%Y-%m")) %>%
      datatable(rownames = FALSE, options = list(pageLength = 10))
  })
}


#######################################################################################
shinyApp(ui, server)
