#######################################################################################
#######################################################################################
################      CLASE 11                     ####################################
################   MCD Carlos Castro Correa        ####################################
################       Shiny 5                     ####################################
#######################################################################################
#######################################################################################

#EJEMPLO 5 (AVANZADO): Tablero operativo de una flota de autotanques
#Que aprenderemos:
  #1. Una funcion que SIMULA datos y un boton para regenerarlos (reactiveVal + observeEvent)
  #2. KPIs con comparacion contra el periodo anterior (delta)
  #3. Graficas interactivas con plotly: serie de tiempo, mapa de calor, ranking
  #4. Tabla con formato (moneda, colores) y boton para descargar el csv filtrado
  #5. Buenas practicas: req(), validate(), funciones auxiliares y codigo ordenado

#Paquetes
library(shiny)
library(bslib)
library(tidyverse)
library(lubridate)
library(plotly)
library(DT)
library(scales)


#######################################################################################
#Funciones auxiliares

#Simula los viajes de una flota de autotanques (cada fila es un viaje)
generar_datos <- function(semilla = 1, dias = 180, hoy = Sys.Date()) {

  set.seed(semilla)

  unidades <- paste0("AT-", sprintf("%02d", 1:15))
  n        <- dias * 12                      #aprox. 12 viajes al dia

  tibble(
    #fecha y hora aleatoria dentro de los ultimos "dias" (restamos segundos a un POSIXct)
    fecha_hora = as.POSIXct(hoy) + 86399 - runif(n, 0, dias * 86400),
    unidad     = sample(unidades, n, replace = TRUE),
    terminal   = sample(c("Toluca", "Tula", "Cuautitlan"), n, replace = TRUE, prob = c(0.45, 0.30, 0.25)),
    km         = round(rlnorm(n, log(140), 0.5)),
    litros     = round(rnorm(n, 18000, 2500)),
    ingreso    = round(km * runif(n, 48, 70) + litros * 0.12),
    retraso    = rbinom(n, 1, 0.18)            #1 = llego tarde
  ) %>%
    mutate(
      fecha      = as_date(fecha_hora),
      hora       = hour(fecha_hora),
      #dia de la semana en espanol (lo armamos a mano para no depender del idioma de la computadora)
      dia_sem    = factor(wday(fecha, week_start = 1), levels = 1:7,
                          labels = c("lun", "mar", "mie", "jue", "vie", "sab", "dom")),
      costo      = round(km * 50.2),           #costo por km (ver el Cotizador)
      utilidad   = ingreso - costo
    ) %>%
    arrange(fecha_hora)
}

#Cambio porcentual entre dos periodos (devuelve texto con flecha para el KPI)
texto_delta <- function(actual, previo) {
  if (is.na(previo) || previo == 0) return("sin periodo de comparacion")
  d <- actual / previo - 1
  paste0(if (d >= 0) "▲ " else "▼ ", percent(abs(d), accuracy = 0.1), " vs periodo anterior")
}

#Caja de KPI hecha a mano con HTML + CSS (mas predecible que value_box en pantallas chicas)
#  titulo: texto chico de arriba | id_valor: numero grande | id_delta: texto de cambio | color: clase CSS
caja_kpi <- function(titulo, id_valor, id_delta, icono, color) {
  div(
    class = paste("kpi", color),
    div(class = "k-top",   icon(icono), span(titulo)),
    div(class = "k-val",   textOutput(id_valor, inline = TRUE)),
    div(class = "k-delta", textOutput(id_delta, inline = TRUE))
  )
}

#Estilos (CSS) del tablero: colores de los KPIs y tabla sin saltos de linea
css_tablero <- "
  .kpi { border-radius: 12px; padding: 14px 18px; color: #fff; }
  .kpi .k-top   { font-size: 0.85rem; opacity: 0.9; display: flex; gap: 8px; align-items: center; }
  .kpi .k-val   { font-size: 2rem; font-weight: 700; line-height: 1.2; margin: 4px 0 2px; }
  .kpi .k-delta { font-size: 0.8rem; opacity: 0.9; }
  .kpi-rojo  { background: #B91C1C; }
  .kpi-gris  { background: #374151; }
  .kpi-verde { background: #047857; }
  .kpi-azul  { background: #1D4ED8; }
  table.dataTable td, table.dataTable th { white-space: nowrap; }
"


#######################################################################################
#UI
ui <- page_sidebar(
  title = "Operacion de flota | Autotanques",
  #Nota: fillable = FALSE hace que la pagina crezca hacia abajo (con scroll) en vez de
  #encajar todo en la altura de la ventana; asi las graficas no se aplastan en pantallas chicas
  fillable = FALSE,
  tags$head(tags$style(HTML(css_tablero))),
  theme = bs_theme(version = 5, primary = "#B91C1C", base_font = font_google("Inter", local = FALSE)),

  #Controles
  sidebar = sidebar(
    width = 290,
    dateRangeInput("fechas", "Periodo", start = Sys.Date() - 29, end = Sys.Date(), language = "es"),
    selectInput("terminal", "Terminal", choices = c("Todas", "Toluca", "Tula", "Cuautitlan")),
    sliderInput("top_n", "Unidades en el ranking", min = 3, max = 15, value = 8, step = 1),
    hr(),
    actionButton("regenerar", "Simular otros datos", icon = icon("rotate"), class = "btn-outline-primary w-100"),
    downloadButton("descargar", "Descargar csv", class = "btn-primary w-100 mt-2")
  ),

  #Fila 1: KPIs
  layout_columns(
    fill = FALSE,
    col_widths = c(3, 3, 3, 3),
    caja_kpi("Viajes",      "kpi_viajes",   "d_viajes",   "truck",       "kpi-rojo"),
    caja_kpi("Litros",      "kpi_litros",   "d_litros",   "droplet",     "kpi-gris"),
    caja_kpi("Utilidad",    "kpi_utilidad", "d_utilidad", "sack-dollar", "kpi-verde"),
    caja_kpi("Puntualidad", "kpi_puntual",  "d_puntual",  "clock",       "kpi-azul")
  ),

  #Fila 2: serie de tiempo + mapa de calor
  #Nota: cada grafica lleva una altura fija en pixeles para que nunca se aplaste
  layout_columns(
    fill = FALSE,
    col_widths = c(7, 5),
    card(card_header("Viajes por dia"),            plotlyOutput("g_serie", height = "320px")),
    card(card_header("Cuando salen los viajes"),   plotlyOutput("g_calor", height = "320px"))
  ),

  #Fila 3: ranking + tabla
  layout_columns(
    fill = FALSE,
    col_widths = c(4, 8),
    card(card_header("Ranking de unidades por utilidad"), plotlyOutput("g_ranking", height = "440px")),
    card(card_header("Detalle de viajes"),                DTOutput("tabla"), min_height = "440px")
  )
)


#######################################################################################
#SERVER
server <- function(input, output, session) {

  #1) Base completa. Cambia cuando el usuario presiona "Simular otros datos"
  semilla <- reactiveVal(1)
  observeEvent(input$regenerar, semilla(semilla() + 1))

  base <- reactive(generar_datos(semilla()))

  #2) Filtro comun (periodo actual y periodo anterior de la misma duracion)
  filtrar <- function(d, ini, fin) {
    d <- d %>% filter(fecha >= ini, fecha <= fin)
    if (input$terminal != "Todas") d <- d %>% filter(terminal == input$terminal)
    d
  }

  datos <- reactive({
    req(input$fechas)
    filtrar(base(), input$fechas[1], input$fechas[2])
  })

  datos_previo <- reactive({
    req(input$fechas)
    dur <- as.numeric(input$fechas[2] - input$fechas[1]) + 1
    filtrar(base(), input$fechas[1] - dur, input$fechas[1] - 1)
  })

  #Resumen de KPIs de una base (lo reutilizamos para actual y previo)
  kpis <- function(d) {
    list(viajes = nrow(d), litros = sum(d$litros), utilidad = sum(d$utilidad),
         puntual = if (nrow(d) == 0) NA_real_ else 1 - mean(d$retraso))
  }
  k_act <- reactive(kpis(datos()))
  k_pre <- reactive(kpis(datos_previo()))

  #3) KPIs
  output$kpi_viajes   <- renderText(comma(k_act()$viajes))
  output$kpi_litros   <- renderText(paste0(comma(k_act()$litros / 1e6, accuracy = 0.01), " M L"))
  output$kpi_utilidad <- renderText(paste0("$", comma(k_act()$utilidad / 1e6, accuracy = 0.01), " M"))
  output$kpi_puntual  <- renderText(percent(k_act()$puntual, accuracy = 0.1))

  output$d_viajes   <- renderText(texto_delta(k_act()$viajes,   k_pre()$viajes))
  output$d_litros   <- renderText(texto_delta(k_act()$litros,   k_pre()$litros))
  output$d_utilidad <- renderText(texto_delta(k_act()$utilidad, k_pre()$utilidad))
  output$d_puntual  <- renderText(texto_delta(k_act()$puntual,  k_pre()$puntual))

  #4) Graficas
  output$g_serie <- renderPlotly({
    validate(need(nrow(datos()) > 0, "No hay viajes con estos filtros"))   #mensaje amable en vez de error

    d <- datos() %>% count(fecha, name = "viajes")

    plot_ly(d, x = ~fecha, y = ~viajes, type = "scatter", mode = "lines+markers",
            line = list(color = "#B91C1C"), marker = list(color = "#B91C1C", size = 5),
            hovertemplate = "%{x|%d %b}: %{y} viajes<extra></extra>") %>%
      layout(xaxis = list(title = ""), yaxis = list(title = "Viajes"))
  })

  output$g_calor <- renderPlotly({
    validate(need(nrow(datos()) > 0, "No hay viajes con estos filtros"))

    d <- datos() %>% count(dia_sem, hora)

    plot_ly(d, x = ~hora, y = ~dia_sem, z = ~n, type = "heatmap",
            colors = c("#FEE2E2", "#B91C1C"),
            hovertemplate = "%{y} a las %{x}:00 h: %{z} viajes<extra></extra>") %>%
      layout(xaxis = list(title = "Hora de salida"), yaxis = list(title = "", autorange = "reversed"))
  })

  output$g_ranking <- renderPlotly({
    validate(need(nrow(datos()) > 0, "No hay viajes con estos filtros"))

    d <- datos() %>%
      group_by(unidad) %>%
      summarise(utilidad = sum(utilidad), .groups = "drop") %>%
      slice_max(utilidad, n = input$top_n) %>%
      mutate(unidad = fct_reorder(unidad, utilidad))

    plot_ly(d, x = ~utilidad, y = ~unidad, type = "bar", orientation = "h",
            marker = list(color = "#B91C1C"),
            hovertemplate = "%{y}: $%{x:,.0f}<extra></extra>") %>%
      layout(xaxis = list(title = "Utilidad (pesos)"), yaxis = list(title = ""))
  })

  #5) Tabla con formato
  output$tabla <- renderDT({
    datos() %>%
      arrange(desc(fecha_hora)) %>%
      transmute(Fecha = format(fecha_hora, "%Y-%m-%d %H:%M"), Unidad = unidad, Terminal = terminal,
                Km = km, Litros = litros, Utilidad = utilidad,
                Retraso = if_else(retraso == 1, "Si", "No")) %>%
      datatable(rownames = FALSE, class = "display compact nowrap",
                options = list(pageLength = 8, dom = "tp", scrollX = TRUE)) %>%
      formatCurrency("Utilidad", digits = 0) %>%
      formatRound(c("Km", "Litros"), digits = 0) %>%
      formatStyle("Retraso", color = styleEqual(c("Si", "No"), c("#B91C1C", "#059669")), fontWeight = "bold")
  })

  #6) Descarga del csv con los filtros aplicados
  output$descargar <- downloadHandler(
    filename = function() paste0("viajes_", format(Sys.Date(), "%Y%m%d"), ".csv"),
    content  = function(file) write_excel_csv(datos() %>% select(-fecha, -hora, -dia_sem), file)
  )
}


#######################################################################################
shinyApp(ui, server)
