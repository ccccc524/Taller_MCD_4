#######################################################################################
#######################################################################################
################      CLASE 11                     ####################################
################   MCD Carlos Castro Correa        ####################################
################       Shiny 5 (version Pro)       ####################################
#######################################################################################
#######################################################################################

#EJEMPLO 5 (AVANZADO): Tablero operativo de una flota de autotanques
#Que aprenderemos:
  #1. Una funcion que SIMULA datos y un boton para regenerarlos (reactiveVal + observeEvent)
  #2. KPIs con comparacion contra el periodo anterior (delta) y minigrafica (sparkline)
  #3. Graficas interactivas con plotly: serie de tiempo, mapa de calor, ranking
  #4. Tabla con formato (moneda, pildoras de color) y boton para descargar el csv filtrado
  #5. Buenas practicas: req(), validate(), funciones auxiliares y codigo ordenado
  #6. NUEVO: diseno propio con CSS (variables de color), modo oscuro / claro con
  #   input_dark_mode() y graficas que cambian de colores junto con el tema

#Paquetes
library(shiny)
library(bslib)        #se necesita bslib >= 0.6 (input_dark_mode y breakpoints)
library(tidyverse)
library(lubridate)
library(plotly)
library(DT)
library(scales)


#######################################################################################
#Colores del tablero (los mismos del tablero comercial en HTML)
ROJO     <- "#EF4444"
ROJO_OSC <- "#B91C1C"
AZUL     <- "#60A5FA"
VERDE    <- "#34D399"
AMBAR    <- "#F59E0B"

COLOR_TERMINAL <- c(Toluca = "#F87171", Tula = "#60A5FA", Cuautitlan = "#34D399")

#Colores que dependen del tema. Los usa plotly, que no puede leer las variables del CSS
paleta <- function(modo = "dark") {
  if (modo == "light") {
    list(bg2 = "#FFFFFF", tx = "#0F1419", tx2 = "#4B5567", tx3 = "#8791A5",
         grid = "#E9ECF2", line2 = "#D6DBE6", heat0 = "#EEF1F6")
  } else {
    list(bg2 = "#0F1218", tx = "#F3F5F9", tx2 = "#A5AEC0", tx3 = "#6B7589",
         grid = "#222A39", line2 = "#2F384A", heat0 = "#1B2130")
  }
}


#######################################################################################
#Funciones auxiliares

#Simula los viajes de una flota de autotanques (cada fila es un viaje)
generar_datos <- function(semilla = 1, dias = 180, hoy = Sys.Date()) {

  set.seed(semilla)

  unidades <- paste0("AT-", sprintf("%02d", 1:15))
  n        <- dias * 12                      #aprox. 12 viajes al dia

  tibble(
    #fecha y hora aleatoria dentro de los ultimos "dias" (restamos segundos a un POSIXct)
    fecha_hora = as.POSIXct(hoy) + 86399 - runif(n, 0, dias * 86400),
    unidad     = sample(unidades, n, replace = TRUE),
    terminal   = sample(c("Toluca", "Tula", "Cuautitlan"), n, replace = TRUE, prob = c(0.45, 0.30, 0.25)),
    km         = round(rlnorm(n, log(140), 0.5)),
    litros     = round(rnorm(n, 18000, 2500)),
    ingreso    = round(km * runif(n, 48, 70) + litros * 0.12),
    retraso    = rbinom(n, 1, 0.18)            #1 = llego tarde
  ) %>%
    mutate(
      fecha      = as_date(fecha_hora),
      hora       = hour(fecha_hora),
      #dia de la semana en espanol (lo armamos a mano para no depender del idioma de la computadora)
      dia_sem    = factor(wday(fecha, week_start = 1), levels = 1:7,
                          labels = c("lun", "mar", "mie", "jue", "vie", "sab", "dom")),
      costo      = round(km * 50.2),           #costo por km (ver el Cotizador)
      utilidad   = ingreso - costo
    ) %>%
    arrange(fecha_hora)
}

#Etiqueta de cambio contra el periodo anterior: verde si sube, roja si baja
#  pp = TRUE compara en puntos porcentuales (para indicadores que ya son un porcentaje)
etiqueta_delta <- function(actual, previo, pp = FALSE) {
  if (is.na(actual) || is.na(previo) || previo == 0) {
    return(span(class = "delta na", "Sin comparativo"))
  }
  d     <- if (pp) (actual - previo) * 100 else actual / previo - 1
  texto <- if (pp) paste0(number(abs(d), accuracy = 0.1), " pp") else percent(abs(d), accuracy = 0.1)
  tagList(
    span(class = paste("delta", if (d >= 0) "up" else "dn"), paste(if (d >= 0) "▲" else "▼", texto)),
    span(class = "vs", "vs periodo anterior")
  )
}

#Minigrafica (sparkline) dibujada a mano como SVG: una linea y un degradado debajo
sparkline <- function(valores, color) {
  if (length(valores) < 2) return(NULL)

  ancho <- 200; alto <- 56
  rango <- max(valores) - min(valores)
  if (rango == 0) rango <- 1

  x <- seq(0, ancho, length.out = length(valores))
  y <- alto - 8 - (valores - min(valores)) / rango * (alto - 22)

  linea <- paste0(c("M", rep("L", length(x) - 1)), round(x, 1), ",", round(y, 1), collapse = "")
  id    <- paste0("sg", substr(color, 2, 7))   #un degradado por color

  HTML(sprintf(
    '<svg class="spark" viewBox="0 0 %d %d" preserveAspectRatio="none">
       <defs><linearGradient id="%s" x1="0" y1="0" x2="0" y2="1">
         <stop offset="0" stop-color="%s" stop-opacity=".35"/><stop offset="1" stop-color="%s" stop-opacity="0"/>
       </linearGradient></defs>
       <path d="%sL%d,%dL0,%dZ" fill="url(#%s)"/>
       <path d="%s" fill="none" stroke="%s" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
     </svg>',
    ancho, alto, id, color, color, linea, ancho, alto, alto, id, linea, color
  ))
}

#Caja de KPI: icono + titulo, numero grande, cambio contra el periodo anterior y sparkline
caja_kpi <- function(titulo, icono, color, valor, unidad, delta, serie) {
  div(
    class = "kpi",
    div(class = "k-lab",
        span(class = "k-ic", style = sprintf("background:%s22;color:%s", color, color), icon(icono)),
        titulo),
    div(class = "k-val", valor, tags$small(unidad)),
    div(delta),
    sparkline(serie, color)
  )
}

#Encabezado de tarjeta con titulo y una pista en gris
titulo_tarjeta <- function(titulo, pista) {
  card_header(div(class = "t-tit", titulo), div(class = "hint", pista))
}

#Renglon de la "Lectura rapida"
insight <- function(icono, color, ...) {
  div(class = "ins",
      span(class = "em", style = sprintf("background:%s22;color:%s", color, color), icon(icono)),
      span(...))
}

#Pildora de color para la tabla (regresa HTML como texto; funciona con vectores)
pildora <- function(texto, color) {
  paste0('<span class="pill"><i style="background:', color, '"></i>', texto, '</span>')
}

#Aspecto comun de todas las graficas de plotly: fondo transparente, ejes discretos, sin barra de herramientas
#  xaxis / yaxis: listas con ajustes extra para cada eje
tema_plotly <- function(p, modo, xaxis = list(), yaxis = list()) {
  pal <- paleta(modo)
  eje <- list(title = "", gridcolor = pal$grid, linecolor = pal$grid, zeroline = FALSE,
              tickfont = list(color = pal$tx3, size = 11), fixedrange = TRUE)

  p %>%
    layout(
      paper_bgcolor = "rgba(0,0,0,0)",
      plot_bgcolor  = "rgba(0,0,0,0)",
      font          = list(family = "Inter, sans-serif", color = pal$tx2, size = 12),
      margin        = list(l = 8, r = 8, t = 8, b = 8),
      xaxis         = modifyList(eje, xaxis),
      yaxis         = modifyList(eje, yaxis),
      hoverlabel    = list(bgcolor = pal$bg2, bordercolor = pal$line2,
                           font = list(color = pal$tx, family = "Inter, sans-serif", size = 12))
    ) %>%
    config(displayModeBar = FALSE, locale = "es")
}


#######################################################################################
#Estilos (CSS) del tablero
#Nota: r"( ... )" es un texto "crudo" de R: permite escribir comillas sin escaparlas.
#Los colores viven en variables (--bg, --card, --tx...) que cambian segun el tema
#(el atributo data-bs-theme del <html>, que controla input_dark_mode)
css_tablero <- r"(
  :root, html[data-bs-theme="dark"] {
    --accent: #EF4444; --accent2: #B91C1C;
    --bg: #0A0C10; --bg2: #0F1218; --card: #141821; --card2: #1A1F2B; --line: #242B38; --line2: #2F384A;
    --tx: #F3F5F9; --tx2: #A5AEC0; --tx3: #6B7589; --good: #34D399; --bad: #F87171;
    --shadow: 0 1px 0 rgba(255,255,255,.03) inset, 0 12px 32px -12px rgba(0,0,0,.6);
    --glow: radial-gradient(900px 420px at 85% -10%, rgba(239,68,68,.14), transparent 60%),
            radial-gradient(700px 380px at -5% 110%, rgba(96,165,250,.08), transparent 60%);
  }
  html[data-bs-theme="light"] {
    --bg: #F4F5F8; --bg2: #FFFFFF; --card: #FFFFFF; --card2: #F7F8FB; --line: #E7EAF0; --line2: #D6DBE6;
    --tx: #0F1419; --tx2: #4B5567; --tx3: #8791A5; --good: #059669; --bad: #DC2626;
    --shadow: 0 1px 2px rgba(16,24,40,.04), 0 12px 28px -14px rgba(16,24,40,.18);
    --glow: radial-gradient(900px 420px at 85% -10%, rgba(185,28,28,.07), transparent 60%);
  }
  /* Le pasamos nuestros colores a Bootstrap */
  html[data-bs-theme] {
    --bs-body-bg: var(--bg); --bs-body-color: var(--tx); --bs-border-color: var(--line);
    --bs-secondary-color: var(--tx3); --bs-emphasis-color: var(--tx);
  }

  /* Fondo con un resplandor suave */
  body { background: var(--glow), var(--bg) !important; background-attachment: fixed !important;
         color: var(--tx); font-size: 14px; -webkit-font-smoothing: antialiased; }
  .bslib-sidebar-layout > .main { background: transparent; padding: 26px 34px 50px; }

  /* ---------- Barra lateral ---------- */
  .bslib-sidebar-layout { --bslib-sidebar-bg: var(--bg2); --bslib-sidebar-fg: var(--tx); border: 0; }
  .bslib-sidebar-layout > .sidebar { background: var(--bg2) !important; border-right: 1px solid var(--line); }
  .brand { display: flex; align-items: center; gap: 12px; margin-bottom: 10px; }
  .logo  { width: 38px; height: 38px; border-radius: 11px; flex: none; display: grid; place-items: center;
           color: #fff; font-size: 16px; background: linear-gradient(135deg, var(--accent), var(--accent2));
           box-shadow: 0 8px 20px -6px rgba(239,68,68,.6); }
  .brand b    { font-size: 15px; letter-spacing: -.01em; display: block; }
  .brand span { font-size: 11.5px; color: var(--tx3); }
  .sidebar .control-label { font-size: 10.5px; letter-spacing: .12em; text-transform: uppercase;
                            color: var(--tx3); font-weight: 600; margin-bottom: 8px; }
  .sidebar hr { border-color: var(--line); opacity: 1; }
  .side-foot  { font-size: 11.5px; color: var(--tx3); line-height: 1.5; border-top: 1px solid var(--line);
                padding-top: 14px; margin-top: 14px; }

  /* Controles */
  .form-control, .form-select, .input-group-text, .input-group-addon {
    background-color: var(--card2) !important; border-color: var(--line) !important;
    color: var(--tx) !important; font-size: 13px; }
  .form-control, .form-select { border-radius: 11px; }
  .form-control:focus, .form-select:focus { border-color: var(--accent) !important;
                                            box-shadow: 0 0 0 3px rgba(239,68,68,.18) !important; }
  .btn { border-radius: 11px; font-weight: 600; font-size: 13px; padding: 10px 16px; transition: all .2s; }
  .btn-primary { background: linear-gradient(135deg, var(--accent), var(--accent2)); border: 0; color: #fff;
                 box-shadow: 0 6px 16px -6px rgba(239,68,68,.7); }
  .btn-primary:hover { transform: translateY(-1px); filter: brightness(1.08); color: #fff; }
  .btn-outline-primary { background: var(--card2); border: 1px solid var(--line2); color: var(--tx); }
  .btn-outline-primary:hover { background: var(--card2); border-color: var(--accent); color: var(--accent); }

  /* ---------- Encabezado ---------- */
  .top    { display: flex; align-items: center; gap: 18px; margin-bottom: 8px; flex-wrap: wrap; }
  .top h1 { font-size: 25px; letter-spacing: -.025em; font-weight: 700; margin: 0; }
  .top .sub { color: var(--tx3); font-size: 13px; margin-top: 2px; }
  .top .modo { margin-left: auto; width: 40px; height: 40px; border-radius: 12px; display: grid;
               place-items: center; border: 1px solid var(--line); background: var(--card); }

  /* ---------- Tarjetas ---------- */
  .card { background: var(--card) !important; border: 1px solid var(--line) !important;
          border-radius: 16px !important; box-shadow: var(--shadow) !important; color: var(--tx);
          animation: aparecer .45s ease both; }
  .card-header { background: transparent !important; border-bottom: 0 !important; padding: 18px 22px 0 !important; }
  .card-body   { padding: 12px 22px 18px !important; }
  .t-tit { font-size: 14px; font-weight: 600; letter-spacing: -.005em; }
  .hint  { font-size: 12px; color: var(--tx3); margin-top: 2px; font-weight: 400; }
  @keyframes aparecer { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: none; } }

  /* ---------- KPIs ---------- */
  .kpi { background: var(--card); border: 1px solid var(--line); border-radius: 16px; box-shadow: var(--shadow);
         padding: 20px 22px; overflow: hidden; height: 100%; animation: aparecer .45s ease both;
         transition: transform .25s, border-color .25s; }
  .kpi:hover  { transform: translateY(-3px); border-color: var(--line2); }
  .kpi .k-lab { display: flex; align-items: center; gap: 8px; color: var(--tx2); font-size: 12.5px; font-weight: 500; }
  .kpi .k-ic  { width: 28px; height: 28px; border-radius: 9px; display: grid; place-items: center; font-size: 13px; }
  .kpi .k-val { font-size: 30px; font-weight: 700; letter-spacing: -.03em; margin: 14px 0 6px;
                font-variant-numeric: tabular-nums; line-height: 1.15; }
  .kpi .k-val small { font-size: 15px; color: var(--tx3); font-weight: 600; margin-left: 4px; }
  .kpi .vs    { font-size: 11.5px; color: var(--tx3); margin-left: 6px; }
  .kpi .spark { display: block; width: calc(100% + 44px); height: 54px; margin: 12px -22px -20px; }
  .delta { display: inline-flex; align-items: center; gap: 5px; font-size: 12px; font-weight: 600;
           padding: 3px 8px; border-radius: 99px; }
  .delta.up { color: var(--good); background: color-mix(in srgb, var(--good) 14%, transparent); }
  .delta.dn { color: var(--bad);  background: color-mix(in srgb, var(--bad) 14%, transparent); }
  .delta.na { color: var(--tx3);  background: var(--card2); }

  /* ---------- Lectura rapida ---------- */
  .insights { display: flex; flex-direction: column; gap: 11px; }
  .ins { display: flex; gap: 12px; padding: 12px 14px; border-radius: 12px; background: var(--card2);
         border: 1px solid var(--line); font-size: 13px; color: var(--tx2); }
  .ins b   { color: var(--tx); }
  .ins .em { width: 30px; height: 30px; border-radius: 9px; display: grid; place-items: center; flex: none; font-size: 13px; }

  /* ---------- Tabla ---------- */
  .dataTables_wrapper { color: var(--tx2); font-size: 13px; }
  table.dataTable { --bs-table-bg: transparent; --bs-table-color: var(--tx); --bs-table-border-color: var(--line);
                    --bs-table-hover-bg: var(--card2); --bs-table-hover-color: var(--tx);
                    color: var(--tx); border-collapse: collapse !important; }
  table.dataTable td, table.dataTable th { white-space: nowrap; padding: 11px 14px !important;
                                           border-bottom: 1px solid var(--line) !important;
                                           font-variant-numeric: tabular-nums; }
  table.dataTable thead th { background: var(--card2) !important; color: var(--tx3) !important; font-size: 11.5px;
                             letter-spacing: .06em; text-transform: uppercase; font-weight: 600; }
  table.dataTable tbody tr:hover > * { background: var(--card2) !important; box-shadow: none !important; }
  .pill   { display: inline-flex; align-items: center; gap: 7px; padding: 3px 10px; border-radius: 99px;
            font-size: 12px; font-weight: 600; background: var(--card2); border: 1px solid var(--line); }
  .pill i { width: 7px; height: 7px; border-radius: 50%; }
  .dataTables_paginate { margin-top: 14px !important; }
  .page-link { background: var(--card2) !important; border-color: var(--line) !important; color: var(--tx2) !important;
               font-weight: 600; font-size: 12.5px; border-radius: 9px !important; margin-left: 6px; }
  .page-item.active .page-link { background: var(--accent) !important; border-color: var(--accent) !important; color: #fff !important; }
  .page-item.disabled .page-link { opacity: .4; }

  /* Mensajes de validate() */
  .shiny-output-error-validation { color: var(--tx3); padding: 40px 10px; text-align: center; }

  @media (max-width: 860px) { .bslib-sidebar-layout > .main { padding: 20px 16px 40px; } }
)"


#######################################################################################
#UI
ui <- page_sidebar(
  window_title = "Operacion de flota | Autotanques",
  #Nota: fillable = FALSE hace que la pagina crezca hacia abajo (con scroll) en vez de
  #encajar todo en la altura de la ventana; asi las graficas no se aplastan en pantallas chicas
  fillable = FALSE,
  tags$head(tags$style(HTML(css_tablero))),
  theme = bs_theme(version = 5, primary = ROJO, base_font = font_google("Inter", local = FALSE)),

  #Controles
  sidebar = sidebar(
    width = 290,
    div(class = "brand",
        div(class = "logo", icon("gas-pump")),
        div(tags$b("Operacion de flota"), span("Autotanques"))),
    dateRangeInput("fechas", "Periodo", start = Sys.Date() - 29, end = Sys.Date(),
                   language = "es", separator = "a"),
    #selectize = FALSE usa el menu nativo, que respeta mejor el modo oscuro
    selectInput("terminal", "Terminal", choices = c("Todas", "Toluca", "Tula", "Cuautitlan"), selectize = FALSE),
    sliderInput("top_n", "Unidades en el ranking", min = 3, max = 15, value = 8, step = 1),
    hr(),
    actionButton("regenerar", "Simular otros datos", icon = icon("rotate"), class = "btn-outline-primary w-100"),
    downloadButton("descargar", "Descargar csv", class = "btn-primary w-100 mt-2"),
    div(class = "side-foot",
        "Datos simulados con fines didacticos.", br(),
        "Taller Data Science con R · MCD Carlos Castro Correa")
  ),

  #Encabezado: titulo, resumen de filtros y boton de tema (oscuro / claro)
  div(class = "top",
      div(h1("Resumen operativo"),
          div(class = "sub", textOutput("subtitulo", inline = TRUE))),
      div(class = "modo", title = "Cambiar tema", input_dark_mode(id = "modo", mode = "dark"))),

  #Fila 1: KPIs (se arman en el server porque llevan delta de color y sparkline)
  uiOutput("kpis"),

  #Fila 2: serie de tiempo + lectura rapida
  #Nota: cada grafica lleva una altura fija en pixeles para que nunca se aplaste
  layout_columns(
    fill = FALSE,
    col_widths = breakpoints(sm = 12, lg = c(8, 4)),
    card(titulo_tarjeta("Viajes por dia", "Pasa el cursor para ver el detalle"),
         plotlyOutput("g_serie", height = "330px")),
    card(titulo_tarjeta("Lectura rapida", "Generada con los filtros actuales"),
         uiOutput("lectura"))
  ),

  #Fila 3: mapa de calor + ranking
  layout_columns(
    fill = FALSE,
    col_widths = breakpoints(sm = 12, lg = c(7, 5)),
    card(titulo_tarjeta("Cuando salen los viajes", "Dia de la semana × hora de salida"),
         plotlyOutput("g_calor", height = "360px")),
    card(titulo_tarjeta("Ranking de unidades", "Utilidad acumulada en el periodo (pesos)"),
         plotlyOutput("g_ranking", height = "360px"))
  ),

  #Fila 4: tabla
  card(titulo_tarjeta("Detalle de viajes", "Los mas recientes primero"),
       DTOutput("tabla"))
)


#######################################################################################
#SERVER
server <- function(input, output, session) {

  #0) Tema actual ("dark" o "light"). Lo manda input_dark_mode; las graficas dependen de el
  modo <- reactive(if (is.null(input$modo)) "dark" else input$modo)

  #1) Base completa. Cambia cuando el usuario presiona "Simular otros datos"
  semilla <- reactiveVal(1)
  observeEvent(input$regenerar, semilla(semilla() + 1))

  base <- reactive(generar_datos(semilla()))

  #2) Filtro comun (periodo actual y periodo anterior de la misma duracion)
  filtrar <- function(d, ini, fin) {
    d <- d %>% filter(fecha >= ini, fecha <= fin)
    if (input$terminal != "Todas") d <- d %>% filter(terminal == input$terminal)
    d
  }

  datos <- reactive({
    req(input$fechas[1], input$fechas[2])
    filtrar(base(), input$fechas[1], input$fechas[2])
  })

  datos_previo <- reactive({
    req(input$fechas[1], input$fechas[2])
    dur <- as.numeric(input$fechas[2] - input$fechas[1]) + 1
    filtrar(base(), input$fechas[1] - dur, input$fechas[1] - 1)
  })

  #Resumen de KPIs de una base (lo reutilizamos para actual y previo)
  kpis <- function(d) {
    list(viajes = nrow(d), litros = sum(d$litros), utilidad = sum(d$utilidad),
         puntual = if (nrow(d) == 0) NA_real_ else 1 - mean(d$retraso))
  }
  k_act <- reactive(kpis(datos()))
  k_pre <- reactive(kpis(datos_previo()))

  #Texto bajo el titulo
  output$subtitulo <- renderText({
    req(input$fechas[1], input$fechas[2])
    paste0(format(input$fechas[1], "%d/%m/%Y"), " a ", format(input$fechas[2], "%d/%m/%Y"), " · ",
           if (input$terminal == "Todas") "Todas las terminales" else paste("Terminal", input$terminal),
           " · ", comma(nrow(datos())), " viajes")
  })

  #3) KPIs
  output$kpis <- renderUI({
    a <- k_act()
    p <- k_pre()

    #Serie diaria para las sparklines
    dia <- datos() %>%
      group_by(fecha) %>%
      summarise(viajes = n(), litros = sum(litros), utilidad = sum(utilidad),
                puntual = 1 - mean(retraso), .groups = "drop")

    layout_columns(
      fill = FALSE,
      col_widths = breakpoints(sm = c(6, 6, 6, 6), lg = c(3, 3, 3, 3)),
      caja_kpi("Viajes", "truck", ROJO,
               comma(a$viajes), "",
               etiqueta_delta(a$viajes, p$viajes), dia$viajes),
      caja_kpi("Litros", "droplet", AZUL,
               comma(a$litros / 1e6, accuracy = 0.01), "M L",
               etiqueta_delta(a$litros, p$litros), dia$litros),
      caja_kpi("Utilidad", "sack-dollar", VERDE,
               paste0("$", comma(a$utilidad / 1e6, accuracy = 0.01)), "M",
               etiqueta_delta(a$utilidad, p$utilidad), dia$utilidad),
      caja_kpi("Puntualidad", "clock", AMBAR,
               if (is.na(a$puntual)) "—" else number(a$puntual * 100, accuracy = 0.1),
               if (is.na(a$puntual)) "" else "%",
               etiqueta_delta(a$puntual, p$puntual, pp = TRUE), dia$puntual)
    )
  })

  #4) Lectura rapida: frases que se escriben solas con los datos filtrados
  output$lectura <- renderUI({
    validate(need(nrow(datos()) > 0, "No hay viajes con estos filtros"))

    d <- datos()

    mejor_dia <- d %>% count(fecha) %>% slice_max(n, n = 1, with_ties = FALSE)
    pico      <- d %>% count(dia_sem, hora) %>% slice_max(n, n = 1, with_ties = FALSE)
    term      <- d %>%
      group_by(terminal) %>%
      summarise(viajes = n(), puntual = 1 - mean(retraso), .groups = "drop") %>%
      slice_max(viajes, n = 1, with_ties = FALSE)
    unidad    <- d %>%
      group_by(unidad) %>%
      summarise(utilidad = sum(utilidad), viajes = n(), .groups = "drop") %>%
      slice_max(utilidad, n = 1, with_ties = FALSE)

    div(
      class = "insights",
      insight("fire", ROJO,
              "El dia con mas movimiento fue el ", tags$b(format(mejor_dia$fecha, "%d/%m")),
              ": ", mejor_dia$n, " viajes."),
      insight("clock", AZUL,
              "La hora pico es ", tags$b(paste0(pico$dia_sem, " a las ", pico$hora, ":00 h")),
              " (", pico$n, " salidas)."),
      insight("location-dot", AMBAR,
              tags$b(term$terminal), " concentra ", percent(term$viajes / nrow(d), accuracy = 1),
              " de los viajes, con puntualidad de ", percent(term$puntual, accuracy = 0.1), "."),
      insight("trophy", VERDE,
              tags$b(unidad$unidad), " es la unidad mas rentable: ", dollar(unidad$utilidad),
              " en ", unidad$viajes, " viajes.")
    )
  })

  #5) Graficas
  output$g_serie <- renderPlotly({
    validate(need(nrow(datos()) > 0, "No hay viajes con estos filtros"))   #mensaje amable en vez de error

    d <- datos() %>% count(fecha, name = "viajes")

    #Area con linea suavizada (shape = "spline") y relleno translucido
    plot_ly(d, x = ~fecha, y = ~viajes, type = "scatter", mode = "lines",
            line = list(color = ROJO, width = 2.6, shape = "spline", smoothing = 0.6),
            fill = "tozeroy", fillcolor = "rgba(239,68,68,0.14)",
            hovertemplate = "%{x|%d %b}: <b>%{y} viajes</b><extra></extra>") %>%
      tema_plotly(modo(),
                  xaxis = list(showgrid = FALSE, tickformat = "%d %b"),
                  yaxis = list(rangemode = "tozero"))
  })

  output$g_calor <- renderPlotly({
    validate(need(nrow(datos()) > 0, "No hay viajes con estos filtros"))

    #complete() agrega las combinaciones dia-hora sin viajes (con cero) para que no queden huecos
    d <- datos() %>%
      count(dia_sem, hora) %>%
      complete(dia_sem, hora = 0:23, fill = list(n = 0))

    #xgap / ygap separan las celdas; la escala va del fondo del tema al rojo
    plot_ly(d, x = ~hora, y = ~dia_sem, z = ~n, type = "heatmap",
            colors = c(paleta(modo())$heat0, ROJO), xgap = 3, ygap = 3, showscale = FALSE,
            hovertemplate = "%{y} a las %{x}:00 h: <b>%{z} viajes</b><extra></extra>") %>%
      tema_plotly(modo(),
                  xaxis = list(title = "Hora de salida", showgrid = FALSE, dtick = 3),
                  yaxis = list(autorange = "reversed", showgrid = FALSE))
  })

  output$g_ranking <- renderPlotly({
    validate(need(nrow(datos()) > 0, "No hay viajes con estos filtros"))

    d <- datos() %>%
      group_by(unidad) %>%
      summarise(utilidad = sum(utilidad), .groups = "drop") %>%
      slice_max(utilidad, n = input$top_n, with_ties = FALSE) %>%
      mutate(unidad = fct_reorder(unidad, utilidad))

    plot_ly(d, x = ~utilidad, y = ~unidad, type = "bar", orientation = "h",
            marker = list(color = ROJO),
            hovertemplate = "%{y}: <b>$%{x:,.0f}</b><extra></extra>") %>%
      tema_plotly(modo(),
                  xaxis = list(tickprefix = "$", tickformat = ",.0f"),
                  yaxis = list(showgrid = FALSE)) %>%
      layout(bargap = 0.35)
  })

  #6) Tabla con formato
  #Nota: escape = FALSE permite que las pildoras (HTML) se dibujen en vez de verse como texto
  output$tabla <- renderDT({
    datos() %>%
      arrange(desc(fecha_hora)) %>%
      transmute(Fecha    = format(fecha_hora, "%Y-%m-%d %H:%M"),
                Unidad   = unidad,
                Terminal = pildora(terminal, COLOR_TERMINAL[terminal]),
                Km       = km,
                Litros   = litros,
                Utilidad = utilidad,
                Retraso  = if_else(retraso == 1, pildora("Si", "#F87171"), pildora("No", "#34D399"))) %>%
      datatable(rownames = FALSE, escape = FALSE, style = "bootstrap5", class = "hover nowrap",
                options = list(pageLength = 8, dom = "tp", scrollX = TRUE,
                               language = list(paginate = list(previous = "‹", `next` = "›"),
                                               emptyTable = "No hay viajes con estos filtros"))) %>%
      formatCurrency("Utilidad", digits = 0) %>%
      formatRound(c("Km", "Litros"), digits = 0) %>%
      formatStyle("Utilidad", fontWeight = "bold")
  })

  #7) Descarga del csv con los filtros aplicados
  output$descargar <- downloadHandler(
    filename = function() paste0("viajes_", format(Sys.Date(), "%Y%m%d"), ".csv"),
    content  = function(file) write_excel_csv(datos() %>% select(-fecha, -hora, -dia_sem), file)
  )
}


#######################################################################################
shinyApp(ui, server)
